import json
import os

import PyQt5
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import threading

from util import get_request_today,get_request_next,get_request_next2,get_request_next3, get_request_biggest_cities
from weather_class import Weather_widget,Weather_big_cities, PushWidget, ColorButton
import calendar
from datetime import date, timedelta

class UI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.resolution=QDesktopWidget().screenGeometry()
        if self.resolution.width()==1920:
            self.sizes_resolution=[32,round(self.resolution.height()//100*(1440/self.resolution.height()))]
        else:
            self.sizes_resolution=[round(self.resolution.width()//100*(3440/self.resolution.width())),round(self.resolution.height()//100*(1440/self.resolution.height()))]

        self.setGeometry(0,0,self.sizes_resolution[0]*60,self.sizes_resolution[1]*60)
        self.setWindowTitle("Skycast")
        self.setWindowFlags(Qt.FramelessWindowHint)

        self.get_theme_settigns()
        self.get_language_settings()
        self.move_screen()
        self.init_UI()

    def get_language_settings(self):
        with open("languages/language.settings",'r') as file:
            self.language_code=file.read()
        with open("languages/"+self.language_code+"/language.json",encoding='utf-8') as file:
            self.language=json.load(file)

    def get_theme_settigns(self):
        with open("settings/theme.settings",'r') as file:
            self.theme=file.read()
        with open("settings/"+self.theme+"/background_color.settings",'r') as file:
            self.background_color=file.read()
        with open("settings/"+self.theme+"/card_background_color.settings",'r') as file:
            self.card_background_color=file.read()
        with open("settings/"+self.theme+"/extra_color.settings",'r') as file:
            self.extra_color=file.read()
        with open("settings/"+self.theme+"/main_color.settings",'r') as file:
            self.main_color=file.read()
        with open("settings/"+self.theme+"/main_color2.settings",'r') as file:
            self.main_color2=file.read()
        with open("settings/"+self.theme+"/refresh_background_color.settings",'r') as file:
            self.refresh_background_color=file.read()

    def init_UI(self):
        self.old_pos = None
        self.pushwidgetFlag=True
        self.settings_opened=False

        self.setStyleSheet("background-color:"+self.background_color+";"
                           "font-family: Helvetica;"
                           "border-radius: 10px;")

        self.init_topbar()
        self.init_main_ui()
        self.init_settings()
    def init_topbar(self):
        img = QPixmap("images/logo/logo.png")
        self.img_name = QLabel(self)
        self.img_name.setGeometry(10, 0, 50, 50)
        self.img_name.setPixmap(img)
        self.img_name.setScaledContents(True)

        self.name=QLabel("Skycast", self)
        self.name.setStyleSheet("color:"+self.main_color+";"
                                "font-size:20px;"
                                "font-weight:200;")
        self.name.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.name.setGeometry(55, 10, self.sizes_resolution[0] * 20, self.sizes_resolution[1] * 2)

        self.btn_minimum = QPushButton("—", self)
        self.btn_minimum.setGeometry((self.sizes_resolution[0] * 60) - 50 * 2, 0, 50, 50)
        self.btn_minimum.clicked.connect(self.minim)
        self.btn_minimum.setStyleSheet("QPushButton{"
                                       "color:"+self.main_color+";"
                                       "font-size: 30px;"
                                       "font-weight: 200;"
                                       "}"
                                       "QPushButton::hover{"
                                       "background-color:red;"
                                       "border:none;"
                                       "border-radius:10px;"
                                       "}")
        self.btn_close = QPushButton("✕", self)
        self.btn_close.setGeometry(( self.sizes_resolution[0] * 60) - 50, 0, 50, 50)
        self.btn_close.clicked.connect(self.close_app)
        self.btn_close.setStyleSheet("QPushButton{"
                                     "color:"+self.main_color+";"
                                     "font-size: 30px;"
                                     "font-weight: 200;"
                                     "}"
                                     "QPushButton::hover{"
                                     "background-color:red;"
                                     "border:none;"
                                     "border-radius:10px;"
                                     "}")

        self.btn_settings = QPushButton("⚙",self)
        self.btn_settings.setGeometry((self.sizes_resolution[0] * 60) - 50, 0+50, 50, 50)
        self.btn_settings.clicked.connect(self.settings_app_action)
        self.btn_settings.setStyleSheet("QPushButton{"
                                     "color:"+self.main_color+";"
                                     "font-size: 30px;"
                                     "font-weight: 200;"
                                     "}"
                                     "QPushButton::hover{"
                                     "background-color:red;"
                                     "border:none;"
                                     "border-radius:10px;"
                                     "}")


        self.text_made_by = QLabel("Made by sdqsz2, Dio", self)
        self.text_made_by.setGeometry(0, self.sizes_resolution[1] * 58, self.sizes_resolution[0] * 60,
                                      self.sizes_resolution[1] * 2)
        self.text_made_by.setStyleSheet("color:"+self.main_color+";"
                                        "font-size:" + str(
            abs(round(self.sizes_resolution[0] - self.sizes_resolution[1]) * 1)) + "px;"
                                                                                   "font-family:Helvetica;")
        self.text_made_by.setAlignment(Qt.AlignCenter)


    def init_settings(self):
        self.settings_list_widget=QWidget(self)
        self.settings_list_widget.setGeometry(0,0,self.sizes_resolution[0]*20,self.sizes_resolution[1]*58)
        self.settings_list_widget.setHidden(True)

        self.settings_layout_list=QVBoxLayout()

        self.settings_layout_list.addStretch()

        self.btn_back_settings=QPushButton(self.language["back"])
        self.btn_back_settings.clicked.connect(self.settings_app_action)
        self.btn_back_settings.setStyleSheet("QPushButton{"
                                                            "color:"+self.main_color+";"
                                                            "font-size: 25px;"
                                                            "font-family: Helvetica;"
                                                            "font-weight: 300;"
                                                            "border:none;"
                                                            "margin-left: 5px;"
                                                            "text-align:left;"
                                                            "}")
        self.settings_layout_list.addWidget(self.btn_back_settings)
        self.btn_back_settings.setFixedSize(self.sizes_resolution[0] * 6, self.sizes_resolution[1] * 4)

        self.settings_layout_list.addStretch(1)

        self.themes_settings_button=QPushButton(self.language["themes"])
        self.themes_settings_button.clicked.connect(self.themes_settings_pressed)
        self.themes_settings_button.setStyleSheet("QPushButton{"
                                                    "color:"+self.main_color+";"
                                                    "background-color:"+self.main_color2+";"
                                                    "font-size: 25px;"
                                                    "font-family: Helvetica;"
                                                    "font-weight: 300;"
                                                    "border:none;"
                                                    "}QPushButton::hover{"
                                                    "color:"+self.main_color2+";"
                                                    "background-color:"+self.main_color+";"
                                                    "font-size: 25px;"
                                                    "font-family: Helvetica;"
                                                    "font-weight: 300;"
                                                    "border:none;}"
                                                    )
        self.settings_layout_list.addWidget(self.themes_settings_button)
        self.themes_settings_button.setFixedSize(self.sizes_resolution[0]*15,self.sizes_resolution[1]*4)


        self.language_button = QPushButton(self.language["language"])
        self.language_button.clicked.connect(self.language_settings_pressed)
        self.language_button.setStyleSheet("QPushButton{"
                                                    "color:"+self.main_color+";"
                                                    "background-color:"+self.main_color2+";"
                                                    "font-size: 25px;"
                                                    "font-family: Helvetica;"
                                                    "font-weight: 300;"
                                                    "border:none;"
                                                    "}QPushButton::hover{"
                                                    "color:"+self.main_color2+";"
                                                    "background-color:"+self.main_color+";"
                                                    "font-size: 25px;"
                                                    "font-family: Helvetica;"
                                                    "font-weight: 300;"
                                                    "border:none;}")
        self.settings_layout_list.addWidget(self.language_button)
        self.language_button.setFixedSize(self.sizes_resolution[0] * 15, self.sizes_resolution[1] * 4)

        self.settings_layout_list.addStretch(1)

        self.about_app_settings = QPushButton(self.language["aboutApp"])
        self.about_app_settings.clicked.connect(self.about_app_pressed)
        self.about_app_settings.setStyleSheet("QPushButton{"
                                                    "color:"+self.main_color+";"
                                                    "background-color:"+self.main_color2+";"
                                                    "font-size: 25px;"
                                                    "font-family: Helvetica;"
                                                    "font-weight: 300;"
                                                    "border:none;"
                                                    "}QPushButton::hover{"
                                                    "color:"+self.main_color2+";"
                                                    "background-color:"+self.main_color+";"
                                                    "font-size: 25px;"
                                                    "font-family: Helvetica;"
                                                    "font-weight: 300;"
                                                    "border:none;}")
        self.settings_layout_list.addWidget(self.about_app_settings)
        self.about_app_settings.setFixedSize(self.sizes_resolution[0] * 15, self.sizes_resolution[1] * 4)


        self.settings_list_widget.setLayout(self.settings_layout_list)

        self.settings_themes_widget=QWidget(self)
        self.settings_themes_widget.setGeometry(self.sizes_resolution[0]*20,50,self.sizes_resolution[0]*40,self.sizes_resolution[1]*60-50)
        self.settings_themes_widget.setHidden(True)

        self.settings_language_widget = QWidget(self)
        self.settings_language_widget.setGeometry(self.sizes_resolution[0] * 20, 50, self.sizes_resolution[0] * 40,
                                              self.sizes_resolution[1] * 60 - 50)
        self.settings_language_widget.setHidden(True)

        self.settings_about_widget = QWidget(self)
        self.settings_about_widget.setGeometry(self.sizes_resolution[0] * 20, 50, self.sizes_resolution[0] * 40,
                                              self.sizes_resolution[1] * 60 - 50)
        self.settings_about_widget.setHidden(True)


        self.themes_layout=QVBoxLayout()
        self.init_themes_layout()

        self.language_layout=QVBoxLayout()
        self.init_language_layout()

        self.about_layout = QVBoxLayout()
        self.init_about_layout()

    def init_about_layout(self):
        layout_team = QHBoxLayout()
        team_lbl=QLabel(self.language["team_lbl"])
        team_lbl.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:38px;"
                                       "font-family:Helvetica;"
                                       "font-weight:400;")
        layout_team.addWidget(team_lbl)
        self.about_layout.addSpacing(30)


        workers=QLabel("Sdqsz2 & Dio")
        workers.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:33px;"
                                       "font-family:Helvetica;"
                                       "font-weight:300;"
                                                      "text-align:center;")
        layout_team.addWidget(workers)

        self.about_layout.addLayout(layout_team)
        self.about_layout.addStretch()

        telegram_layout=QHBoxLayout()
        telegram_lbl=QLabel(self.language["telegram_lbl"])
        telegram_lbl.setStyleSheet("color:" + self.main_color + ";"
                                                          "font-size:40px;"
                                                          "font-family:Helvetica;"
                                                          "font-weight:400;"
                                                                )
        telegram_layout.addWidget(telegram_lbl)
        telegram_layout.addSpacing(30)
        telegram_btn=QPushButton()
        telegram_btn.setFixedSize(round(self.sizes_resolution[0]*2.5),round(self.sizes_resolution[0]*2.5))
        telegram_btn.setIcon(QIcon("images/logo/telegram.png"))
        telegram_btn.setStyleSheet("QPushButton{"
        "border:none;"
        "background-color:none;}QPushButton::hover{"
        "border:1px solid "+self.main_color+";"
        "border-radius:20px;"
        "background-color:whitesmoke;"
        "}")
        telegram_btn.setIconSize(QSize(self.sizes_resolution[0]*2,self.sizes_resolution[0]*2))
        telegram_btn.clicked.connect(self.telegram_action)
        telegram_layout.addWidget(telegram_btn)
        telegram_layout.addStretch()
        self.about_layout.addLayout(telegram_layout)
        self.about_layout.addStretch()

        warning_layout=QVBoxLayout()
        warning=QLabel(self.language["warning"])
        warning.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:27px;"
                                       "font-family:Helvetica;"
                                       "font-weight:300;"
                                                      "text-align:left;")
        warning_layout.addWidget(warning)
        comercial_prohibited=QLabel(self.language["comercial_prohibited"])
        comercial_prohibited.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:27px;"
                                       "font-family:Helvetica;"
                                       "font-weight:300;"
                                                      "text-align:left;")
        warning_layout.addWidget(comercial_prohibited)
        self.about_layout.addLayout(warning_layout)
        self.about_layout.addStretch()

        with open("settings/version.settings",'r')as file:
            version=file.read()
        version_lbl=QLabel(self.language["version"]+version)
        version_lbl.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:30px;"
                                       "font-family:Helvetica;"
                                       "font-weight:400;"
                                                      "text-align:left;")
        self.about_layout.addWidget(version_lbl)

        self.settings_about_widget.setLayout(self.about_layout)

    def telegram_action(self):
        url = 'https://t.me/psevdocoders'
        QDesktopServices.openUrl(QUrl(url))
    def init_language_layout(self):

        lbl_choose_language=QLabel(self.language["chooseLanguage"])
        lbl_choose_language.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:38px;"
                                       "font-family:Helvetica;"
                                       "font-weight:400;")
        self.language_layout.addWidget(lbl_choose_language)
        self.language_layout.addSpacing(50)

        object_names_languages=["english","russian"]
        object_names_origin=["English","Русский"]

        self.list_senders_objects_language=[]
        ready_layout=QHBoxLayout()
        ready_layout.addStretch()
        for i in range(2):
            language_btn=QPushButton(object_names_origin[i])
            language_btn.setStyleSheet("QPushButton{"
                                                    "color:"+self.main_color+";"
                                                    "background-color:"+self.main_color2+";"
                                                    "font-size: 30px;"
                                                    "font-weight: 300;"
                                                    "border:none;"
                                                    "}QPushButton::hover{"
                                                    "color:"+self.main_color2+";"
                                                    "background-color:"+self.main_color+";"
                                                    "font-size: 30px;"
                                                    "font-weight: 300;"
                                                    "border:none;}"
                                       )
            language_btn.setObjectName(object_names_languages[i])
            language_btn.clicked.connect(self.btn_language_action)
            ready_layout.addWidget(language_btn)
            ready_layout.addSpacing(30)
            language_btn.setFixedSize(self.sizes_resolution[0]*10,self.sizes_resolution[1]*5)
            self.list_senders_objects_language.append(language_btn)
        ready_layout.addStretch()
        self.language_layout.addLayout(ready_layout)
        self.language_layout.addStretch()

        text_warning = QLabel(self.language["warningSettings"])
        text_warning.setStyleSheet("color:" + self.main_color + ";"
                                                                "font-size: 18px;"
                                                                "font-family:Helvetica;"
                                                                "font-weight: 200;"
                                   )
        self.language_layout.addWidget(text_warning)

        self.settings_language_widget.setLayout(self.language_layout)

    def btn_language_action(self):
        sender=self.sender()
        with open("languages/language.settings",'w') as file:
            file.write(sender.objectName())



    def init_themes_layout(self):
        lbl_ready_themes=QLabel(self.language["readyThemes"])
        lbl_ready_themes.setStyleSheet("color:"+self.main_color+";"
                                       "font-size:38px;"
                                       "font-family:Helvetica;"
                                       "font-weight:400;")
        self.themes_layout.addWidget(lbl_ready_themes)
        self.themes_layout.addSpacing(50)

        ready_themes_layout=QHBoxLayout()

        counter=0
        list_theme_btns=["_black","_white","_custom"]
        list_theme_btns_colors=["black","whitesmoke","#6C92AF"]
        self.list_senders_objects = {}
        for i in list_theme_btns:
            button=QPushButton()
            button.setStyleSheet("border:1px solid #B5B8B1;"
            "border-radius: 25px;"
            "background-color:"+list_theme_btns_colors[counter]+";")
            button.setFixedSize(50,50)
            button.setObjectName(i)
            button.clicked.connect(self.btn_theme_action)
            ready_themes_layout.addWidget(button)
            ready_themes_layout.addSpacing(30)
            counter+=1
            self.list_senders_objects[i]=button
        ready_themes_layout.addStretch()

        theme_ready_widget=QWidget()
        theme_ready_widget.setLayout(ready_themes_layout)
        self.themes_layout.addWidget(theme_ready_widget)

        self.themes_layout.addStretch()
        text_colortext=QLabel(self.language["colors"])
        text_colortext.setStyleSheet("color:"+self.main_color+";"
                                     "font-size: 38px;"
                                     "font-family:Helvetica;"
                                     "font-weight: 400;")

        self.themes_layout.addWidget(text_colortext)
        self.themes_layout.addSpacing(50)
        main_text_layout=QHBoxLayout()

        text_colortext_main_text=QLabel(self.language["mainColor"])
        text_colortext_main_text.setStyleSheet("color:"+self.main_color+";"
                                     "font-size: 25px;"
                                     "font-family:Helvetica;"
                                     "font-weight: 300;")

        self.text_colortext_main_btn=ColorButton()
        self.text_colortext_main_btn.setText(self.language["chooseColor"])
        self.text_colortext_main_btn.setStyleSheet("color:"+self.main_color+";"
                                                   "font-size:25px;"
                                                   "font-family:Helvetica;"
                                                   "font-weight:300;"
                                                   "border-radius: 10px;")
        main_text_layout.addWidget(text_colortext_main_text)
        main_text_layout.addWidget(self.text_colortext_main_btn)

        self.themes_layout.addLayout(main_text_layout)
        self.themes_layout.addSpacing(5)

        main_text_layout2 = QHBoxLayout()
        text_colortext_main_text2 = QLabel(self.language["secondMainColor"])
        text_colortext_main_text2.setStyleSheet("color:"+self.main_color+";"
                                               "font-size: 25px;"
                                               "font-family:Helvetica;"
                                               "font-weight: 300;")

        self.text_colortext_main_btn2 = ColorButton()
        self.text_colortext_main_btn2.setText(self.language["chooseColor"])
        self.text_colortext_main_btn2.setStyleSheet("color:"+self.main_color+";"
                                                   "font-size:25px;"
                                                   "font-family:Helvetica;"
                                                   "font-weight:300;"
                                                   "border-radius: 10px;")
        main_text_layout2.addWidget(text_colortext_main_text2)
        main_text_layout2.addWidget(self.text_colortext_main_btn2)

        self.themes_layout.addLayout(main_text_layout2)
        self.themes_layout.addSpacing(5)



        extra_text_layout = QHBoxLayout()

        text_colortext_extra_text = QLabel(self.language["extraColor"])
        text_colortext_extra_text.setStyleSheet("color:"+self.main_color+";"
                                               "font-size: 25px;"
                                               "font-family:Helvetica;"
                                               "font-weight: 300;")

        self.text_colortext_extra_btn = ColorButton()
        self.text_colortext_extra_btn.setText(self.language["chooseColor"])
        self.text_colortext_extra_btn.setStyleSheet("color:"+self.main_color+";"
                                                   "font-size:25px;"
                                                   "font-family:Helvetica;"
                                                   "font-weight:300;"
                                                    "border-radius: 10px;"
                                                  )
        extra_text_layout.addWidget(text_colortext_extra_text)
        extra_text_layout.addWidget(self.text_colortext_extra_btn)

        self.themes_layout.addLayout(extra_text_layout)
        self.themes_layout.addSpacing(5)



        background_text_layout = QHBoxLayout()

        text_background_text = QLabel(self.language["mainBackgroundColor"])
        text_background_text.setStyleSheet("color:"+self.main_color+";"
                                                "font-size: 25px;"
                                                "font-family:Helvetica;"
                                                "font-weight: 300;")

        self.text_background_btn = ColorButton()
        self.text_background_btn.setText(self.language["chooseColor"])
        self.text_background_btn.setStyleSheet("color:"+self.main_color+";"
                                                    "font-size:25px;"
                                                    "font-family:Helvetica;"
                                                    "font-weight:300;"
                                                    "border-radius: 10px;")
        background_text_layout.addWidget(text_background_text)
        background_text_layout.addWidget(self.text_background_btn)

        self.themes_layout.addLayout(background_text_layout)
        self.themes_layout.addSpacing(5)


        background_card_text_layout = QHBoxLayout()

        text_background_card_text = QLabel(self.language["cardBackgroundColor"])
        text_background_card_text.setStyleSheet("color:"+self.main_color+";"
                                           "font-size: 25px;"
                                           "font-family:Helvetica;"
                                           "font-weight: 300;")

        self.text_background_card_btn = ColorButton()
        self.text_background_card_btn.setText(self.language["chooseColor"])
        self.text_background_card_btn.setStyleSheet("color:"+self.main_color+";"
                                               "font-size:25px;"
                                               "font-family:Helvetica;"
                                               "font-weight:300;"
                                               "border-radius: 10px;")
        background_card_text_layout.addWidget(text_background_card_text)
        background_card_text_layout.addWidget(self.text_background_card_btn)

        self.themes_layout.addLayout(background_card_text_layout)
        self.themes_layout.addSpacing(5)


        background_refref_text_layout = QHBoxLayout()

        text_background_refresh_text = QLabel(self.language["refreshBackgroundColor"])
        text_background_refresh_text.setStyleSheet("color:"+self.main_color+";"
                                                "font-size: 25px;"
                                                "font-family:Helvetica;"
                                                "font-weight: 300;")

        self.text_background_refresh_btn = ColorButton()
        self.text_background_refresh_btn.setText(self.language["chooseColor"])
        self.text_background_refresh_btn.setStyleSheet("color:"+self.main_color+";"
                                                    "font-size:25px;"
                                                    "font-family:Helvetica;"
                                                    "font-weight:300;"
                                                    "border-radius: 10px;")
        background_refref_text_layout.addWidget(text_background_refresh_text)
        background_refref_text_layout.addWidget(self.text_background_refresh_btn)

        self.themes_layout.addLayout(background_refref_text_layout)
        self.themes_layout.addSpacing(5)
        self.themes_layout.addStretch()

        btn_delete = QPushButton(self.language["remove"])
        btn_delete.setStyleSheet("color:"+self.main_color+";"
                                 "background-color:#9B111E;"
                                 "border-radius:10px;"
                                 "font-size: 25px;"
                                 "font-family")
        btn_delete.clicked.connect(self.settings_custom_setdefault)
        self.themes_layout.addWidget(btn_delete)

        btn_submit=QPushButton(self.language["save"])
        btn_submit.setStyleSheet("color:"+self.main_color+";"
                                 "background-color:"+self.refresh_background_color+";"
                                 "border-radius:10px;"
                                 "font-size: 25px;"
                                 "font-family")
        btn_submit.clicked.connect(self.settings_themes_get_set)
        self.themes_layout.addWidget(btn_submit)

        text_warning=QLabel(self.language["warningSettings"])
        text_warning.setStyleSheet("color:"+self.main_color+";"
                                                "font-size: 18px;"
                                                "font-family:Helvetica;"
                                                "font-weight: 200;"
                                   )
        self.themes_layout.addWidget(text_warning)
        self.settings_themes_widget.setLayout(self.themes_layout)
    def btn_theme_action(self):
        sender=self.sender()
        with open("settings/theme.settings",'w') as file:
            file.write(sender.objectName())
        dict_clicked={"_black":"border:3px solid #5764EF;border-radius:25px;background-color: black;",
                      "_white":"border:3px solid #5764EF;border-radius:25px;background-color: whitesmoke;",
                      "_custom":"border:3px solid #5764EF;border-radius:25px;background-color:#6C92AF;"}
        dict_unclicked={"_black":"border:3px solid #B5B8B1;border-radius:25px;background-color: black;",
                      "_white":"border:3px solid #B5B8B1;border-radius:25px;background-color: whitesmoke;",
                      "_custom":"border:3px solid #B5B8B1;border-radius:25px;background-color:#6C92AF;"}
        list_senders_objectnames=["_black","_white","_custom"]


        for i in list_senders_objectnames:
            if sender.objectName()==i:
                sender.setStyleSheet(dict_clicked[sender.objectName()])
            else:
                self.list_senders_objects[i].setStyleSheet(dict_unclicked[i])


    def settings_custom_setdefault(self):
        list_files=["main_color.settings","main_color2.settings","extra_color.settings","background_color.settings","card_background_color.settings","main_color.settings"]
        for i in range(len(list_files)):
            with open("settings/_black/"+list_files[i],'r') as file:
                value=file.read()
            with open("settings/_custom/"+list_files[i],'w') as file:
                file.write(value)

    def settings_themes_get_set(self):
        list_settings=[self.text_colortext_main_btn.color(),self.text_colortext_main_btn2.color(),self.text_colortext_extra_btn.color(),
                       self.text_background_btn.color(),self.text_background_card_btn.color(),
                       self.text_background_refresh_btn.color()]
        list_files = ["main_color.settings","main_color2.settings", "extra_color.settings", "background_color.settings",
                      "card_background_color.settings", "main_color.settings"]
        for i in range(len(list_files)):
            if list_settings[i]!=None:
                with open("settings/_custom/"+list_files[i],'w') as file:
                    file.write(list_settings[i])

    def settings_app_action(self):
        if self.settings_opened==False:
            self.settings_list_widget.setHidden(False)
            self.settings_themes_widget.setHidden(False)
            self.settings_language_widget.setHidden(False)
            self.settings_about_widget.setHidden(False)
            self.settings_opened=True
        elif self.settings_opened==True:
            self.settings_list_widget.setHidden(True)
            self.settings_themes_widget.setHidden(True)
            self.settings_language_widget.setHidden(True)
            self.settings_about_widget.setHidden(True)
            self.settings_opened=False

    def themes_settings_pressed(self):
        self.settings_themes_widget.setHidden(False)
        self.settings_language_widget.setHidden(True)
        self.settings_about_widget.setHidden(True)

    def language_settings_pressed(self):
        self.settings_themes_widget.setHidden(True)
        self.settings_language_widget.setHidden(False)
        self.settings_about_widget.setHidden(True)

    def about_app_pressed(self):
        self.settings_themes_widget.setHidden(True)
        self.settings_language_widget.setHidden(True)
        self.settings_about_widget.setHidden(False)

    def init_main_ui(self):
        threading.Thread(target=self.new_thread, daemon=True).start()
        self.init_right_bar()


    def init_right_bar(self):
        self.place=QComboBox(self)
        self.place.setGeometry(self.sizes_resolution[0]*43,self.sizes_resolution[1]*3,self.sizes_resolution[0]*13,self.sizes_resolution[1]*3)
        self.place.setStyleSheet("color:"+self.main_color+";"
                                               "font-family: Helvetica;"
                                               "font-size: 30px;"
                                               "font-weight: 500;"
                                               "margin-top:10px;"

                                 )
        self.place.addItem(self.language["yourLocation"],0)
        self.place.addItem(self.language["Moscow"],1)
        self.place.addItem(self.language["SaintPetersburg"],2)
        self.place.addItem(self.language["Sochi"],3)
        self.place.addItem(self.language["Krasnodar"],4)
        self.place.addItem(self.language["Stavropol"],5)
        self.place.addItem(self.language["Volgograd"],6)
        self.place.addItem(self.language["CustomCoords"],7)
        self.place.setCurrentIndex(0)
        self.place.activated.connect(self.refresh_btn)

        self.custom_coordinates_lbl=QLabel(self.language["CustomCoordsV2"],self)
        self.custom_coordinates_lbl.setStyleSheet("color:"+self.main_color+";"
                                                  "font-size:24px;"
                                                  "font-family:Helvetica;"
                                                  "font-weight:300;")
        self.custom_coordinates_lbl.setFixedSize(150,30)
        self.latitude_text=QLineEdit(self)
        self.longtude_text=QLineEdit(self)
        self.latitude_text.setStyleSheet("color:"+self.main_color+";"
                                         "font-family:Helvetica;"
                                         "font-size:24px;"
                                         )
        self.longtude_text.setStyleSheet("color:"+self.main_color+";"
                                         "font-family:Helvetica;"
                                         "font-size:24px;"
                                         )
        self.latitude_text.setPlaceholderText(self.language["latitude"])
        self.longtude_text.setPlaceholderText(self.language["longitude"])

        horizontal_layout=QHBoxLayout()
        horizontal_layout.addWidget(self.custom_coordinates_lbl)
        horizontal_layout.addWidget(self.latitude_text)
        horizontal_layout.addWidget(self.longtude_text)



        self.coordinates_widget=QWidget(self)
        self.coordinates_widget.setGeometry(self.sizes_resolution[0]*43,self.sizes_resolution[1]*6,self.sizes_resolution[0]*13,self.sizes_resolution[1]*5)
        self.coordinates_widget.setLayout(horizontal_layout)

        self.btn_refresh=QPushButton(self.language["refresh"],self)
        self.btn_refresh.setStyleSheet("color:"+self.main_color+";"
                                       "background-color:"+self.refresh_background_color+";"
                                       "border-radius:10px;"
                                       "font-family:Helvetica;"
                                       "font-size:24px;")
        self.btn_refresh.setGeometry(self.sizes_resolution[0]*43,self.sizes_resolution[1]*12,self.sizes_resolution[0]*13,self.sizes_resolution[1]*4)
        self.btn_refresh.clicked.connect(self.refresh_btn_action)

        self.line2 = QLabel(self)
        self.line2.setGeometry(self.sizes_resolution[0] * 43, self.sizes_resolution[1]*18, self.sizes_resolution[0]*13,
                              2)
        self.line2.setStyleSheet("color:"+self.main_color+";"
                                "border-radius:10px;"
                                "border:1px solid "+self.main_color+";")
        self.line2.setText("_")

        self.layout_extra_info=QVBoxLayout()

        self.extra_date=QLabel(self.language["clickWeatherCast"])
        self.extra_date.setStyleSheet("color:"+self.main_color2+";"
                                      "font-family: Helvetica;"
                                      "font-size:25px;"
                                      "font-weight: 500;"
                                      "margin-left:-5px;"
                                      )
        self.extra_date.setAlignment(Qt.AlignLeft| Qt.AlignVCenter)
        self.extra_date.setFixedSize(self.sizes_resolution[0]*15,self.sizes_resolution[1]*3)
        self.layout_extra_info.addWidget(self.extra_date)

        self.img_weather_extra = QLabel()
        pixmap=QPixmap("images/forecast/sun_clear/sun.png")
        self.img_weather_extra.setStyleSheet("border:none;"
                                       "margin-left:5px;"
                                      )
        self.img_weather_extra.setScaledContents(True)
        self.img_weather_extra.setPixmap(pixmap)
        self.img_weather_extra.setFixedSize(120,120)
        self.layout_extra_info.addWidget(self.img_weather_extra)

        layout_temp=QHBoxLayout()
        self.temperature_extra = QLabel(self.language["temperature"])
        self.temperature_extra.setStyleSheet("color:"+self.main_color2+";"
                                      "font-family: Helvetica;"
                                      "font-size:23px;"
                                      "font-weight: 400;"
                                      "margin-left:-1px;"
                                      )
        self.temperature_extra.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.temperature_extra_value = QLabel(self.language["unknown"])
        self.temperature_extra_value.setStyleSheet("color:"+self.extra_color+";"
                                             "font-family: Helvetica;"
                                             "font-size:23px;"
                                             "font-weight: 400;"
                                             "margin-left:5px;"
                                             )
        self.temperature_extra_value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        layout_temp.addWidget(self.temperature_extra)
        layout_temp.addWidget(self.temperature_extra_value)
        self.layout_extra_info.addLayout(layout_temp)

        layout_feeling_temp=QHBoxLayout()
        self.temperature_feeling_extra = QLabel(self.language["feelingTemperature"])
        self.temperature_feeling_extra.setStyleSheet("color:"+self.main_color2+";"
                                             "font-family: Helvetica;"
                                             "font-size:22px;"
                                             "font-weight: 400;"
                                             "margin-left:-1px;"
                                             )
        self.temperature_feeling_extra.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.temperature_feeling_extra_value = QLabel(self.language["unknown"])
        self.temperature_feeling_extra_value.setStyleSheet("color:"+self.extra_color+";"
                                                     "font-family: Helvetica;"
                                                     "font-size:23px;"
                                                     "font-weight: 400;"
                                                     "margin-left:5px;"
                                                     )
        self.temperature_feeling_extra_value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        layout_feeling_temp.addWidget(self.temperature_feeling_extra)
        layout_feeling_temp.addWidget(self.temperature_feeling_extra_value)
        self.layout_extra_info.addLayout(layout_feeling_temp)


        layout_wind_speed=QHBoxLayout()
        self.wind_speed_extra = QLabel(self.language["windSpeed"])
        self.wind_speed_extra.setStyleSheet("color:"+self.main_color2+";"
                                                     "font-family: Helvetica;"
                                                     "font-size:23px;"
                                                     "font-weight: 400;"
                                                     "margin-left:-1px;"
                                                     )
        self.wind_speed_extra.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.wind_speed_extra_value = QLabel(self.language["unknown"])
        self.wind_speed_extra_value.setStyleSheet("color:"+self.extra_color+";"
                                            "font-family: Helvetica;"
                                            "font-size:23px;"
                                            "font-weight: 400;"
                                            "margin-left:5px;"
                                            )
        self.wind_speed_extra_value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        layout_wind_speed.addWidget(self.wind_speed_extra)
        layout_wind_speed.addWidget(self.wind_speed_extra_value)
        self.layout_extra_info.addLayout(layout_wind_speed)

        layout_relative_humidity=QHBoxLayout()
        self.relative_humidity_extra = QLabel(self.language["relativeHumidity"])
        self.relative_humidity_extra.setStyleSheet("color:"+self.main_color2+";"
                                            "font-family: Helvetica;"
                                            "font-size:22px;"
                                            "font-weight: 400;"
                                            "margin-left:-1px;"
                                            )
        self.relative_humidity_extra.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.relative_humidity_extra_value = QLabel(self.language["unknown"])
        self.relative_humidity_extra_value.setStyleSheet("color:"+self.extra_color+";"
                                                   "font-family: Helvetica;"
                                                   "font-size:23px;"
                                                   "font-weight: 400;"
                                                   "margin-left:5px;"
                                                   )
        self.relative_humidity_extra_value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        layout_relative_humidity.addWidget(self.relative_humidity_extra)
        layout_relative_humidity.addWidget(self.relative_humidity_extra_value)
        self.layout_extra_info.addLayout(layout_relative_humidity)

        self.weather_code_extra = QLabel(self.language["unknown"])
        self.weather_code_extra.setStyleSheet("color:"+self.extra_color+";"
                                                   "font-family: Helvetica;"
                                                   "font-size:23px;"
                                                   "font-weight: 400;"
                                                   "margin-left:5px;"
                                                   )
        self.weather_code_extra.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.weather_code_extra.setFixedSize(self.sizes_resolution[0] * 15, self.sizes_resolution[1] * 3)
        self.layout_extra_info.addWidget(self.weather_code_extra)

        self.extra_widget=QWidget(self)
        self.extra_widget.setGeometry(self.sizes_resolution[0]*43,self.sizes_resolution[1]*20,self.sizes_resolution[0]*13,round(self.sizes_resolution[1]*36.4))
        self.extra_widget.setLayout(self.layout_extra_info)
        self.extra_widget.setStyleSheet("background-color:"+self.card_background_color+";"
                                        "border-radius:15px;")



        self.init_weather_cards()
    def init_weather_cards(self):

        self.weather_layout_today_init=Weather_widget(self.background_color,self.card_background_color,self.extra_color,self.main_color,self.main_color2,self.refresh_background_color)
        self.weather_layout_today=self.weather_layout_today_init.get_layout()
        self.weather_widget_today=QPushButton()
        self.weather_widget_today.clicked.connect(self.today_clicked)
        self.weather_widget_today.setLayout(self.weather_layout_today)
        self.weather_widget_today.setStyleSheet("background-color:"+self.card_background_color+";"
                                                "border-radius:25px;")
        self.weather_widget_today.setFixedSize(self.sizes_resolution[0]*7,self.sizes_resolution[1]*25)


        self.weather_layout_tommorow_init = Weather_widget(self.background_color,self.card_background_color,self.extra_color,self.main_color,self.main_color2,self.refresh_background_color)
        self.weather_layout_tommorow = self.weather_layout_tommorow_init.get_layout()
        self.weather_widget_tommorow=QPushButton()
        self.weather_widget_tommorow.clicked.connect(self.tommorow_clicked)
        self.weather_widget_tommorow.setLayout(self.weather_layout_tommorow)
        self.weather_widget_tommorow.setStyleSheet("background-color:"+self.card_background_color+";"
                                                "border-radius:25px;")
        self.weather_widget_tommorow.setFixedSize(self.sizes_resolution[0]*7,self.sizes_resolution[1]*25)

        self.weather_layout_aftertommorow_init = Weather_widget(self.background_color,self.card_background_color,self.extra_color,self.main_color,self.main_color2,self.refresh_background_color)
        self.weather_layout_aftertommorow = self.weather_layout_aftertommorow_init.get_layout()
        self.weather_widget_aftertommorow = QPushButton()
        self.weather_widget_aftertommorow.clicked.connect(self.aftertommorow_clicked)
        self.weather_widget_aftertommorow.setLayout(self.weather_layout_aftertommorow)
        self.weather_widget_aftertommorow.setStyleSheet("background-color:"+self.card_background_color+";"
                                                   "border-radius:25px;")
        self.weather_widget_aftertommorow.setFixedSize(self.sizes_resolution[0] * 7, self.sizes_resolution[1] * 25)

        self.weather_layout_aftertommorow2_init = Weather_widget(self.background_color,self.card_background_color,self.extra_color,self.main_color,self.main_color2,self.refresh_background_color)
        self.weather_layout_aftertommorow2 = self.weather_layout_aftertommorow2_init.get_layout()
        self.weather_widget_aftertommorow2 = QPushButton()
        self.weather_widget_aftertommorow2.clicked.connect(self.aftertommorow2_clicked)
        self.weather_widget_aftertommorow2.setLayout(self.weather_layout_aftertommorow2)
        self.weather_widget_aftertommorow2.setStyleSheet("background-color:"+self.card_background_color+";"
                                                        "border-radius:25px;")
        self.weather_widget_aftertommorow2.setFixedSize(self.sizes_resolution[0] * 7, self.sizes_resolution[1] * 25)

        weather_horizontal_layout=QHBoxLayout()
        weather_horizontal_layout.addWidget(self.weather_widget_today)
        weather_horizontal_layout.addWidget(self.weather_widget_tommorow)
        weather_horizontal_layout2=QHBoxLayout()
        weather_horizontal_layout2.addWidget(self.weather_widget_aftertommorow)
        weather_horizontal_layout2.addWidget(self.weather_widget_aftertommorow2)

        weather_global_layout=QVBoxLayout()
        weather_global_layout.addLayout(weather_horizontal_layout)
        weather_global_layout.addLayout(weather_horizontal_layout2)


        self.weather_widget=QWidget(self)
        self.weather_widget.setLayout(weather_global_layout)
        self.weather_widget.setGeometry(self.sizes_resolution[0]*19,50,self.sizes_resolution[0]*20,self.sizes_resolution[1]*54)


        self.big_cities_layout=QVBoxLayout()
        self.big_cities_widget=QWidget(self)
        self.big_cities_widget.setGeometry(self.sizes_resolution[0]*2,50,self.sizes_resolution[0]*13,self.sizes_resolution[1]*54)
        if self.language_code=="russian":
            self.cities = {'Москва': [55.4507, 37.3656], 'Санкт-Петербург': [59.57, 30.19], 'Сочи': [43.5992, 39.7257],
                  'Краснодар': [45.0448, 38.976], 'Ставрополь': [45.0428, 41.9734], 'Волгоград': [48.4309, 44.3006]}
        elif self.language_code=="english":
            self.cities = {'Moscow': [55.4507, 37.3656], 'Saint-Petersburg': [59.57, 30.19], 'Sochi': [43.5992, 39.7257],
                           'Krasnodar': [45.0448, 38.976], 'Stavropol': [45.0428, 41.9734],
                           'Volgograd': [48.4309, 44.3006]}
        self.get_cities_layout(self.cities)
        self.big_cities_widget.setLayout(self.big_cities_layout)

        self.line=QLabel(self)
        self.line.setGeometry(self.sizes_resolution[0]*18,self.sizes_resolution[1]*15,2,self.sizes_resolution[1]*25)
        self.line.setStyleSheet("color:"+self.main_color+";"
                                "border-radius:10px;"
                                "border:1px solid "+self.main_color+";")
        self.line.setText("|")

        self.pushwidget_layout = PushWidget(self.background_color,self.card_background_color,self.extra_color,self.main_color,self.main_color2,self.refresh_background_color)
        self.pushwidget = QWidget(self)
        self.pushwidget.setStyleSheet("background-color:"+self.background_color+";"
                                      "border-radius: 10px;"
                                      "border: 1px solid "+self.card_background_color+";")
        self.pushwidget.setGeometry(self.sizes_resolution[0] * 20, self.sizes_resolution[1] * 25,
                                    self.sizes_resolution[0] * 20, self.sizes_resolution[1] * 10)
        self.pushwidget.setLayout(self.pushwidget_layout)
        self.pushwidget_layout.close_btn.clicked.connect(self.pushwidget_hide)

    def pushwidget_show(self):
        if self.pushwidgetFlag != True:
            self.pushwidget.setHidden(False)

    def pushwidget_hide(self):
        self.pushwidget.setHidden(True)
        if self.pushwidgetFlag!=False:
            self.pushwidgetFlag = False

    def pushwidgetText(self,text):
        self.pushwidget_layout.setText(text)

    def get_info(self,mode,coordinates=[50.21,40.2]):
        self.pushwidget_show()
        self.data_today = self.request(mode, coordinates)
        self.data_tommorow = self.request_next(mode, coordinates)
        self.data_aftertommorow = self.request_next2(mode, coordinates)
        self.data_aftertommorow2 = self.request_next3(mode, coordinates)

        self.converted_data_today = self.convert_data_today(self.data_today, 1)
        self.converted_data_next = self.convert_data_next(self.data_tommorow, 2)
        self.converted_data_next2 = self.convert_data_next(self.data_aftertommorow, 3)
        self.converted_data_next3 = self.convert_data_next(self.data_aftertommorow2, 4)


    def new_thread(self):
        self.get_info('me',[50.21,40.2])

        self.set_info()


    def set_info(self):
        self.weather_layout_today_init.set_info(self.language["currentWeather"], self.converted_data_today['date'],
                                      self.converted_data_today['img_path'], self.converted_data_today['temperature'],
                                      self.converted_data_today['feeling_temperature'],
                                      self.converted_data_today['wind_speed'],
                                      self.converted_data_today['relative_humidity'],
                                      self.converted_data_today['weather_code'])
        self.weather_layout_tommorow_init.set_info(self.language["tommorow"], self.converted_data_next['date'],
                                         self.converted_data_next['img_path'],
                                         self.converted_data_next['temperature_max'],
                                         self.converted_data_next['temperature_min'],
                                         self.converted_data_next['wind_speed'],
                                         self.converted_data_next['relative_humidity'],
                                         self.converted_data_next['weather_code'])
        self.weather_layout_aftertommorow_init.set_info(self.language["afterTommorow"], self.converted_data_next2['date'],
                                              self.converted_data_next2['img_path'],
                                              self.converted_data_next2['temperature_max'],
                                              self.converted_data_next2['temperature_min'],
                                              self.converted_data_next2['wind_speed'],
                                              self.converted_data_next2['relative_humidity'],
                                              self.converted_data_next2['weather_code'])
        self.weather_layout_aftertommorow2_init.set_info(self.language["after2Days"], self.converted_data_next3['date'],
                                               self.converted_data_next3['img_path'],
                                               self.converted_data_next3['temperature_max'],
                                               self.converted_data_next3['temperature_min'],
                                               self.converted_data_next3['wind_speed'],
                                               self.converted_data_next3['relative_humidity'],
                                               self.converted_data_next3['weather_code'])

        self.pushwidget_hide()

    def refresh_btn(self,index):
        self.code=self.place.itemData(index)
    def refresh_btn_action(self):
        if self.code==0:
            self.get_info('me',[50.21,40.2])
            self.set_info()
        elif self.code>0 and self.code<7:
            if self.language_code=="russian":
                cities_names=['Москва','Санкт-Петербург','Сочи','Краснодар','Ставрополь','Волгоград']
            elif self.language_code=="english":
                cities_names = ['Moscow', 'Saint-Petersburg', 'Sochi', 'Krasnodar', 'Stavropol', 'Volgograd']

            self.get_info('mee',self.cities[cities_names[self.code-1]])
            self.set_info()

        else:
            latitude=self.latitude_text.text()
            longitude=self.longtude_text.text()
            self.get_info('mee',[latitude,longitude])
            self.set_info()


    def today_clicked(self):
        self.extra_date.setText(self.language["today"])
        self.temperature_extra_value.setText(self.converted_data_today['temperature'])
        self.temperature_extra.setText(self.language["temperature"])
        self.temperature_feeling_extra_value.setText(self.converted_data_today['feeling_temperature'])
        self.temperature_feeling_extra.setText(self.language["feelingTemperature"])
        self.wind_speed_extra_value.setText(self.converted_data_today['wind_speed'])
        self.relative_humidity_extra_value.setText(self.converted_data_today['relative_humidity'])
        self.weather_code_extra.setText(self.converted_data_today['weather_code'])
        pixmap=QPixmap(self.converted_data_today['img_path'])
        self.img_weather_extra.setPixmap(pixmap)
    def tommorow_clicked(self):
        self.extra_date.setText(self.language["tommorow"])
        self.temperature_extra_value.setText(self.converted_data_next['temperature_max'])
        self.temperature_extra.setText(self.language["maxTemperature"])
        self.temperature_feeling_extra_value.setText(self.converted_data_next['temperature_min'])
        self.temperature_feeling_extra.setText(self.language["minTemperature"])
        self.wind_speed_extra_value.setText(self.converted_data_next['wind_speed'])
        self.relative_humidity_extra_value.setText(self.converted_data_next['relative_humidity'])
        self.weather_code_extra.setText(self.converted_data_next['weather_code'])
        pixmap = QPixmap(self.converted_data_next['img_path'])
        self.img_weather_extra.setPixmap(pixmap)

    def aftertommorow_clicked(self):
        self.extra_date.setText(self.language["afterTommorow"])
        self.temperature_extra_value.setText(self.converted_data_next2['temperature_max'])
        self.temperature_extra.setText(self.language["maxTemperature"])
        self.temperature_feeling_extra_value.setText(self.converted_data_next2['temperature_min'])
        self.temperature_feeling_extra.setText(self.language["minTemperature"])
        self.wind_speed_extra_value.setText(self.converted_data_next2['wind_speed'])
        self.relative_humidity_extra_value.setText(self.converted_data_next2['relative_humidity'])
        self.weather_code_extra.setText(self.converted_data_next2['weather_code'])
        pixmap = QPixmap(self.converted_data_next2['img_path'])
        self.img_weather_extra.setPixmap(pixmap)

    def aftertommorow2_clicked(self):
        self.extra_date.setText(self.language["after2Days"])
        self.temperature_extra_value.setText(self.converted_data_next3['temperature_max'])
        self.temperature_extra.setText(self.language["maxTemperature"])
        self.temperature_feeling_extra_value.setText(self.converted_data_next3['temperature_min'])
        self.temperature_feeling_extra.setText(self.language["minTemperature"])
        self.wind_speed_extra_value.setText(self.converted_data_next3['wind_speed'])
        self.relative_humidity_extra_value.setText(self.converted_data_next3['relative_humidity'])
        self.weather_code_extra.setText(self.converted_data_next3['weather_code'])
        pixmap = QPixmap(self.converted_data_next3['img_path'])
        self.img_weather_extra.setPixmap(pixmap)

    def get_cities_layout(self,cities):
        cities_weather2={}
        for i in cities:
            cities_weather2[i]=get_request_biggest_cities(cities[i])

        for i in cities_weather2:
            ans=self.convert_data_cities(cities_weather2[i])
            weather_big_cities=Weather_big_cities(self.background_color,self.card_background_color,self.extra_color,self.main_color,self.main_color2,self.refresh_background_color)
            weather_big_cities_layout=weather_big_cities.get_layout()
            weather_big_cities.set_info(ans['weather_code'],ans['temperature'],i)
            weather_big_cities_widget=QWidget()
            weather_big_cities_widget.setLayout(weather_big_cities_layout)
            weather_big_cities_widget.setStyleSheet("background-color:"+self.card_background_color+";"
                                                    
                                                    "border-radius:25px;")
            self.big_cities_layout.addWidget(weather_big_cities_widget)
            self.big_cities_layout.addSpacing(10)



    def convert_data_cities(self,data):
        weather_statuses_img = {0: "images/forecast/sun_clear/sun.png",
                                     1: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     2: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     3: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     45: "images/forecast/fog/fog.png", 48: "images/forecast/fog/fog.png",
                                     51: "images/forecast/drizzle/drizzle.png",
                                     53: "images/forecast/drizzle/drizzle.png",
                                     55: "images/forecast/drizzle/drizzle.png",
                                     56: "images/forecast/drizzle/drizzle.png",
                                     57: "images/forecast/drizzle/drizzle.png",
                                     61: "images/forecast/drizzle/weak_medium_rain.png",
                                     63: "images/forecast/drizzle/weak_medium_rain.png",
                                     65: "images/forecast/drizzle/strong_rain.png", 66: "images/forecast/drizzle/strong_rain.png",
                                     67: "images/forecast/drizzle/strong_rain.png",
                                     71: "images/forecast/snowfall/snowfall.png",
                                     73: "images/forecast/snowfall/snowfall.png",
                                     75: "images/forecast/snowfall/snowfall.png",
                                     77: "images/forecast/snowfall/snowfall.png",
                                     80: "images/forecast/drizzle/rain_shower.png",
                                     81: "images/forecast/drizzle/rain_shower.png",
                                     82: "images/forecast/drizzle/rain_shower.png",
                                     85: "images/forecast/snowfall/snowfall.png", 86: "images/forecast/snowfall/snowfall.png",
                                     95: "images/forecast/thunder/thunder.png",
                                     96: "images/forecast/thunder/thunder_with_rain.png",
                                     99: "images/forecast/thunder/thunder_with_rain.png"}
        converted_data={}
        try:
            data['temperature_2m']=round(data['temperature'])
            data['weather_code']=round(data['weather_code'])
        except Exception as e:
            print(Exception)

        if data['temperature_2m']<0:
            converted_data['temperature']=str(data['temperature_2m'])
        elif data['temperature_2m']==0:
            converted_data['temperature']=str(0)
        else:
            converted_data['temperature']="+"+str(data['temperature_2m'])

        converted_data['weather_code']=weather_statuses_img[data['weather_code']]

        return converted_data

    def convert_data_today(self,data,day):
        if self.language_code=="russian":
            self.weather_statuses={0:"Ясно", 1:"Облачно", 2:"Облачно",3:"Пасмурно",45:"Туман",48:"Изморось",51:"Морось", 53:"Морось", 55:"Морось", 56:"Морось", 57:"Морось",61:"Дождь",63:"Дождь",65:"Дождь", 66:"Дождь",67:"Дождь", 71:"Снегопад",73:"Снегопад",75:"Снегопад",77:"Снегопад",80:"Ливень",81:"Ливень",82:"Ливень",85:"Снегопад",86:"Снегопад",95:"Гроза",96:"Гроза с градом",99:"Гроза с градом"}
        elif self.language_code=="english":
            self.weather_statuses={0:"Clear", 1:"Cloudy", 2:"Cloudy",3:"Cloudy",45:"Fog",48:"Drizzle",51:"Drizzle", 53:"Drizzle", 55:"Drizzle", 56:"Drizzle", 57:"Drizzle",61:"Rain",63:"Rain",65:"Rain", 66:"Rain",67:"Rain", 71:"Snowfall",73:"Snowfall",75:"Snowfall",77:"Snowfall",80:"Rainfall",81:"Rainfall",82:"Rainfall",85:"Snowfall",86:"Snowfall",95:"Thunderstorm",96:"Thunderstorm with hail",99:"thunderstorm with hail"}

        self.weather_statuses_img = {0: "images/forecast/sun_clear/sun.png",
                                     1: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     2: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     3: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     45: "images/forecast/fog/fog.png", 48: "images/forecast/fog/fog.png",
                                     51: "images/forecast/drizzle/drizzle.png",
                                     53: "images/forecast/drizzle/drizzle.png",
                                     55: "images/forecast/drizzle/drizzle.png",
                                     56: "images/forecast/drizzle/drizzle.png",
                                     57: "images/forecast/drizzle/drizzle.png",
                                     61: "images/forecast/drizzle/weak_medium_rain.png",
                                     63: "images/forecast/drizzle/weak_medium_rain.png",
                                     65: "images/forecast/drizzle/strong_rain.png", 66: "images/forecast/drizzle/strong_rain.png",
                                     67: "images/forecast/drizzle/strong_rain.png",
                                     71: "images/forecast/snowfall/snowfall.png",
                                     73: "images/forecast/snowfall/snowfall.png",
                                     75: "images/forecast/snowfall/snowfall.png",
                                     77: "images/forecast/snowfall/snowfall.png",
                                     80: "images/forecast/drizzle/rain_shower.png",
                                     81: "images/forecast/drizzle/rain_shower.png",
                                     82: "images/forecast/drizzle/rain_shower.png",
                                     85: "images/forecast/snowfall/snowfall.png", 86: "images/forecast/snowfall/snowfall.png",
                                     95: "images/forecast/thunder/thunder.png",
                                     96: "images/forecast/thunder/thunder_with_rain.png",
                                     99: "images/forecast/thunder/thunder_with_rain.png"}
        converted_data_today={}
        for key in self.data_today:
            try:
                converted_data_today[key]=round(self.data_today[key])
            except:
                converted_data_today[key]=self.data_today[key]
                continue
        return_data={}
        if converted_data_today['temperature']>0:
            return_data['temperature']="+"+str(converted_data_today['temperature'])
        elif converted_data_today['temperature']==0:
            return_data['temperature'] = str(converted_data_today['temperature'])
        else:
            return_data['temperature'] =  str(converted_data_today['temperature'])
        return_data['weather_code']=self.weather_statuses[converted_data_today['weather_code']]
        return_data['img_path']=self.weather_statuses_img[converted_data_today['weather_code']]
        return_data['wind_speed']="🌫 "+str(round(converted_data_today['wind_speed']/3.6,2))+" м/c"
        return_data['relative_humidity']="💧 "+str(converted_data_today['relative_humidity'])+"%"
        if converted_data_today['feeling_temperature']>0:
            return_data['feeling_temperature']="+"+str(converted_data_today['feeling_temperature'])
        elif converted_data_today['feeling_temperature']==0:
            return_data['feeling_temperature']=str(converted_data_today['feeling_temperature'])
        else:
            return_data['feeling_temperature'] =  str(converted_data_today['feeling_temperature'])
        self.days = self.calendar_days()
        return_data['date']=self.days[day]

        return return_data

    def convert_data_next(self,data,day):
        if self.language_code == "russian":
            weather_statuses = {0: "Ясно", 1: "Облачно", 2: "Облачно", 3: "Пасмурно", 45: "Туман", 48: "Изморось",
                                     51: "Морось", 53: "Морось", 55: "Морось", 56: "Морось", 57: "Морось", 61: "Дождь",
                                     63: "Дождь", 65: "Дождь", 66: "Дождь", 67: "Дождь", 71: "Снегопад", 73: "Снегопад",
                                     75: "Снегопад", 77: "Снегопад", 80: "Ливень", 81: "Ливень", 82: "Ливень",
                                     85: "Снегопад", 86: "Снегопад", 95: "Гроза", 96: "Гроза с градом",
                                     99: "Гроза с градом"}
        elif self.language_code == "english":
            weather_statuses = {0: "Clear", 1: "Cloudy", 2: "Cloudy", 3: "Cloudy", 45: "Fog", 48: "Drizzle",
                                     51: "Drizzle", 53: "Drizzle", 55: "Drizzle", 56: "Drizzle", 57: "Drizzle",
                                     61: "Rain", 63: "Rain", 65: "Rain", 66: "Rain", 67: "Rain", 71: "Snowfall",
                                     73: "Snowfall", 75: "Snowfall", 77: "Snowfall", 80: "Rainfall", 81: "Rainfall",
                                     82: "Rainfall", 85: "Snowfall", 86: "Snowfall", 95: "Thunderstorm",
                                     96: "Thunderstorm with hail", 99: "thunderstorm with hail"}

        weather_statuses_img = {0: "images/forecast/sun_clear/sun.png",
                                     1: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     2: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     3: "images/forecast/sun_with_clouds/sun_with_clouds.png",
                                     45: "images/forecast/fog/fog.png", 48: "images/forecast/fog/fog.png",
                                     51: "images/forecast/drizzle/drizzle.png",
                                     53: "images/forecast/drizzle/drizzle.png",
                                     55: "images/forecast/drizzle/drizzle.png",
                                     56: "images/forecast/drizzle/drizzle.png",
                                     57: "images/forecast/drizzle/drizzle.png",
                                     61: "images/forecast/drizzle/weak_medium_rain.png",
                                     63: "images/forecast/drizzle/weak_medium_rain.png",
                                     65: "images/forecast/drizzle/strong_rain.png", 66: "images/forecast/drizzle/strong_rain.png",
                                     67: "images/forecast/drizzle/strong_rain.png",
                                     71: "images/forecast/snowfall/snowfall.png",
                                     73: "images/forecast/snowfall/snowfall.png",
                                     75: "images/forecast/snowfall/snowfall.png",
                                     77: "images/forecast/snowfall/snowfall.png",
                                     80: "images/forecast/drizzle/rain_shower.png",
                                     81: "images/forecast/drizzle/rain_shower.png",
                                     82: "images/forecast/drizzle/rain_shower.png",
                                     85: "images/forecast/snowfall/snowfall.png", 86: "images/forecast/snowfall/snowfall.png",
                                     95: "images/forecast/thunder/thunder.png",
                                     96: "images/forecast/thunder/thunder_with_rain.png",
                                     99: "images/forecast/thunder/thunder_with_rain.png"}
        converted_data_next={}

        for key in data:
            try:
                converted_data_next[key]=round(data[key])
            except:
                converted_data_next[key]=data[key]
                continue

        return_data={}

        if converted_data_next['temperature_max']>0:
            return_data['temperature_max']="+"+str(converted_data_next['temperature_max'])
        elif converted_data_next['temperature_max']==0:
            return_data['temperature_max'] = str(converted_data_next['temperature_max'])
        else:
            return_data['temperature_max'] =  str(converted_data_next['temperature_max'])
        return_data['weather_code']=weather_statuses[converted_data_next['weather_code']]
        return_data['img_path']=weather_statuses_img[converted_data_next['weather_code']]
        return_data['wind_speed']="🌫 "+str(round(converted_data_next['wind_speed_max']/3.6,2))+" м/c"
        return_data['relative_humidity']="💧 "+str(converted_data_next['precipitation_sum'])+"мм"
        if converted_data_next['temperature_min']>0:
            return_data['temperature_min']="+"+str(converted_data_next['temperature_min'])
        elif converted_data_next['temperature_min']==0:
            return_data['temperature_min']=str(converted_data_next['temperature_min'])
        else:
            return_data['temperature_min'] =   str(converted_data_next['temperature_min'])

        return_data['date']=self.days[day]

        return return_data


    def calendar_days(self):
        today=date.today()
        yesterday=today-timedelta(days=1)
        tomorrow = today + timedelta(days=1)
        the_day_next = today + timedelta(days=2)
        the_day_next_next = today + timedelta(days=3)
        if self.language_code=="russian":
            days_week={"Mon":"Пон","Tue":"Вто","Wed":"Сре","Thu":"Чет","Fri":"Пят","Sat":"Суб","Sun":"Вос"}
        elif self.language_code=="english":
            days_week = {"Mon": "Mon", "Tue": "Tue", "Wed": "Wed", "Thu": "Thu", "Fri": "Fri", "Sat": "Sat",
                         "Sun": "Sun"}
        days=[days_week[calendar.day_name[yesterday.weekday()][:3]]+" "+ yesterday.strftime('%d-%m'),
              days_week[calendar.day_name[today.weekday()][:3]]+" "+ today.strftime('%d-%m'),
              days_week[calendar.day_name[tomorrow.weekday()][:3]]+" "+ tomorrow.strftime('%d-%m'),
              days_week[calendar.day_name[the_day_next.weekday()][:3]]+" "+ the_day_next.strftime('%d-%m'),
              days_week[calendar.day_name[the_day_next_next.weekday()][:3]] + " " + the_day_next_next.strftime('%d-%m')]
        return days

    def request(self,mode,coordinates):
        ans=get_request_today(mode,coordinates)
        return ans

    def request_next(self,mode,coordinates):
        ans=get_request_next(mode,coordinates)
        return ans

    def request_next2(self, mode, coordinates):
        ans = get_request_next2(mode, coordinates)
        return ans
    def request_next3(self,mode,coordinates):
        ans=get_request_next3(mode,coordinates)
        return ans
    def request_cities(self,coordinates):
        ans=get_request_biggest_cities(coordinates)
        return ans
    def close_app(self):
        self.close()
    def minim(self):
        self.showMinimized()
    def move_screen(self):
        self.move((self.resolution.width() // 2) - (self.frameSize().width() // 2),
                  (self.resolution.height() // 2) - (self.frameSize().height() // 2))
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.old_pos = event.pos()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.old_pos = None

    def mouseMoveEvent(self, event):
        if not self.old_pos:
            return

        delta = event.pos() - self.old_pos
        self.move(self.pos() + delta)


def main():
    app=QApplication(sys.argv)

    window=UI()
    window.show()
    sys.exit(app.exec_())

if __name__=="__main__":
    main()


# Warning: This project is developed by sdqsz2 and Dio using the free API Open-Meteo, PyQt5.
# Commercial use is prohibited according to the API terms of use.
# Предупреждение: Данный проект разработан sdqsz2 и Dio с использованием бесплатного API Open-Meteo, PyQt5.
# Коммерческое использование запрещено в соответствии с условиями использования API.