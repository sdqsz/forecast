import geocoder
import openmeteo_requests
import requests_cache
from retry_requests import retry
from datetime import date, timedelta, UTC,datetime


def get_request_today(mode="me", coordinates=[54.02, 54.02]):
    try:
        if mode == "me":
            g = geocoder.ip('me')
            latitude, longitude = g.latlng
        else:
            latitude, longitude = coordinates

        cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
        retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
        openmeteo = openmeteo_requests.Client(session=retry_session)

        url = "https://api.open-meteo.com/v1/forecast"
        tomorrow = date.today() + timedelta(days=1)
        after_tomorrow = date.today() + timedelta(days=2)
        after_after_tomorrow = date.today() + timedelta(days=3)
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": ["temperature_2m", "precipitation", "weather_code", "wind_speed_10m", "relative_humidity_2m",
                        "cloud_cover", "rain", "apparent_temperature", "wind_gusts_10m", "is_day", "snowfall",
                        "wind_direction_10m"],
            "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_sum", "weather_code", "wind_speed_10m_max"],
            "start_date": date.today().isoformat(),
            "end_date": tomorrow.isoformat(),
            "timezone": "auto"
        }

        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]

        data_return = {
            'coordinates': [response.Latitude(), response.Longitude()],
            'elevation': response.Elevation(),
            'timezone': [response.Timezone(), response.TimezoneAbbreviation()],
            'timezone_dif': response.UtcOffsetSeconds(),
            'time': response.Current().Time(),
            'temperature': response.Current().Variables(0).Value(),
            'precipitation': response.Current().Variables(1).Value(),
            'weather_code': response.Current().Variables(2).Value(),
            'wind_speed': response.Current().Variables(3).Value(),
            'relative_humidity': response.Current().Variables(4).Value(),
            'cloud_cover': response.Current().Variables(5).Value(),
            'rain': response.Current().Variables(6).Value(),
            'feeling_temperature': response.Current().Variables(7).Value(),
            'wind_gusts': response.Current().Variables(8).Value(),
            'is_day': response.Current().Variables(9).Value(),
            'snowfall': response.Current().Variables(10).Value(),
            'wind_direction': response.Current().Variables(11).Value()}

        return data_return
    except Exception as e:
        return {'error': f"Ошибка: {str(e)}"}

def get_request_next(mode="me", coordinates=[54.02, 54.02]):
    try:
        if mode == "me":
            g = geocoder.ip('me')
            latitude, longitude = g.latlng
        else:
            latitude, longitude = coordinates

        cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
        retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
        openmeteo = openmeteo_requests.Client(session=retry_session)

        url = "https://api.open-meteo.com/v1/forecast"
        tomorrow = date.today() + timedelta(days=1)
        after_tomorrow = date.today() + timedelta(days=2)
        after_after_tomorrow = date.today() + timedelta(days=3)
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": ["temperature_2m", "precipitation", "weather_code", "wind_speed_10m", "relative_humidity_2m",
                        "cloud_cover", "rain", "apparent_temperature", "wind_gusts_10m", "is_day", "snowfall",
                        "wind_direction_10m"],
            "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_sum", "weather_code", "wind_speed_10m_max"],
            "start_date": tomorrow.isoformat(),
            "end_date": after_tomorrow.isoformat(),
            "timezone": "auto"
        }

        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]

        data_return = {
            'date': tomorrow.isoformat(),
            'temperature_max': response.Daily().Variables(0).ValuesAsNumpy()[0],
            'temperature_min': response.Daily().Variables(1).ValuesAsNumpy()[0],
            'precipitation_sum': response.Daily().Variables(2).ValuesAsNumpy()[0],
            'weather_code': response.Daily().Variables(3).ValuesAsNumpy()[0],
            'wind_speed_max': response.Daily().Variables(4).ValuesAsNumpy()[0]
            }

        return data_return
    except Exception as e:
        return {'error': f"Ошибка: {str(e)}"}

def get_request_next2(mode="me", coordinates=[54.02, 54.02]):
    try:
        if mode == "me":
            g = geocoder.ip('me')
            latitude, longitude = g.latlng
        else:
            latitude, longitude = coordinates

        cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
        retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
        openmeteo = openmeteo_requests.Client(session=retry_session)

        url = "https://api.open-meteo.com/v1/forecast"
        tomorrow = date.today() + timedelta(days=1)
        after_tomorrow = date.today() + timedelta(days=2)
        after_after_tomorrow = date.today() + timedelta(days=3)
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": ["temperature_2m", "precipitation", "weather_code", "wind_speed_10m", "relative_humidity_2m",
                        "cloud_cover", "rain", "apparent_temperature", "wind_gusts_10m", "is_day", "snowfall",
                        "wind_direction_10m"],
            "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_sum", "weather_code", "wind_speed_10m_max"],
            "start_date": tomorrow.isoformat(),
            "end_date": after_after_tomorrow.isoformat(),
            "timezone": "auto"
        }

        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]

        data_return = {
            'date': after_tomorrow.isoformat(),
            'temperature_max': response.Daily().Variables(0).ValuesAsNumpy()[1],
            'temperature_min': response.Daily().Variables(1).ValuesAsNumpy()[1],
            'precipitation_sum': response.Daily().Variables(2).ValuesAsNumpy()[1],
            'weather_code': response.Daily().Variables(3).ValuesAsNumpy()[1],
            'wind_speed_max': response.Daily().Variables(4).ValuesAsNumpy()[1]
            }

        return data_return
    except Exception as e:
        return {'error': f"Ошибка: {str(e)}"}

def get_request_next3(mode="me", coordinates=[54.02, 54.02]):
    try:
        if mode == "me":
            g = geocoder.ip('me')
            latitude, longitude = g.latlng
        else:
            latitude, longitude = coordinates

        cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
        retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
        openmeteo = openmeteo_requests.Client(session=retry_session)

        url = "https://api.open-meteo.com/v1/forecast"
        tomorrow = date.today() + timedelta(days=1)
        after_tomorrow = date.today() + timedelta(days=2)
        after_after_tomorrow = date.today() + timedelta(days=3)
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": ["temperature_2m", "precipitation", "weather_code", "wind_speed_10m", "relative_humidity_2m",
                        "cloud_cover", "rain", "apparent_temperature", "wind_gusts_10m", "is_day", "snowfall",
                        "wind_direction_10m"],
            "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_sum", "weather_code", "wind_speed_10m_max"],
            "start_date": tomorrow.isoformat(),
            "end_date": after_after_tomorrow.isoformat(),
            "timezone": "auto"
        }

        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]

        data_return = {
            'date': after_after_tomorrow.isoformat(),
            'temperature_max': response.Daily().Variables(0).ValuesAsNumpy()[2],
            'temperature_min': response.Daily().Variables(1).ValuesAsNumpy()[2],
            'precipitation_sum': response.Daily().Variables(2).ValuesAsNumpy()[2],
            'weather_code': response.Daily().Variables(3).ValuesAsNumpy()[2],
            'wind_speed_max': response.Daily().Variables(4).ValuesAsNumpy()[2]
            }

        return data_return
    except Exception as e:
        return {'error': f"Ошибка: {str(e)}"}

def get_request_biggest_cities(coordinates):
    try:
        latitude,longitude=coordinates

        cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
        retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
        openmeteo = openmeteo_requests.Client(session=retry_session)

        url = "https://api.open-meteo.com/v1/forecast"
        tomorrow = date.today() + timedelta(days=1)
        after_tomorrow = date.today() + timedelta(days=2)
        after_after_tomorrow = date.today() + timedelta(days=3)
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": ["temperature_2m", "weather_code"],
            "start_date": date.today().isoformat(),
            "end_date": tomorrow.isoformat(),
            "timezone": "auto"
        }

        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]

        data_return = {
            'temperature': response.Current().Variables(0).Value(),
            'weather_code': response.Current().Variables(1).Value(),
            }

        return data_return
    except Exception as e:
        return {'error': f"Ошибка: {str(e)}"}
# Warning: This project is developed by sdqsz2 and Dio using the free API Open-Meteo, PyQt5.
# Commercial use is prohibited according to the API terms of use.
# Предупреждение: Данный проект разработан sdqsz2 и Dio с использованием бесплатного API Open-Meteo, PyQt5.
# Коммерческое использование запрещено в соответствии с условиями использования API.