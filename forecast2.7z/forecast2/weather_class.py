
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import json


class Weather_widget(QVBoxLayout):
    def __init__(self,background_color,card_background_color,extra_color,main_color,main_color2,refresh_background_color):
        super().__init__()
        self.setSpacing(0)
        self.weekdate=QLabel("Today")
        self.weekdate.setStyleSheet("color:"+main_color2+";"
                                    "font-family: Helvetica;"
                                    "font-size:24px;"
                                    "font-weight:500;"
                                    "margin-left:4px;")
        self.weekdate.setAlignment(Qt.AlignLeft)
        self.addWidget(self.weekdate)

        self.month_date=QLabel("Wed 01-01")
        self.month_date.setStyleSheet("color:"+extra_color+";"
                                    "font-family: Helvetica;"
                                    "font-size:20px;"
                                    "font-weight:300;"
                                    "margin-left:5px;")
        self.month_date.setAlignment(Qt.AlignLeft)
        self.addWidget(self.month_date)

        self.addSpacing(20)

        self.img_weather=QLabel()
        pixmap=QPixmap("images/forecast/sun_clear/sun.png")
        self.img_weather.setFixedSize(100,100)
        self.img_weather.setStyleSheet("border:none;"
                                       "margin-left:5px;")
        self.img_weather.setPixmap(pixmap)
        self.img_weather.setScaledContents(True)

        self.addWidget(self.img_weather,alignment=Qt.AlignLeft)

        self.addSpacing(20)

        self.temperature=QLabel("+23°")
        self.temperature.setStyleSheet("color: "+main_color2+";"
                                               "font-family: Helvetica;"
                                               "font-size: 25px;"
                                               "font-weight: 400;"
                                               "margin-left:5px;")
        self.temperature.setAlignment(Qt.AlignLeft)

        self.feeling_temperature = QLabel("+23°")
        self.feeling_temperature.setStyleSheet("color: "+extra_color+";"
                                       "font-family: Helvetica;"
                                       "font-size: 25px;"
                                       "font-weight: 300;"
                                       "margin-left:5px;")
        self.feeling_temperature.setAlignment(Qt.AlignLeft)

        temperature_layout=QHBoxLayout()
        temperature_layout.addWidget(self.temperature)
        temperature_layout.addWidget(self.feeling_temperature)

        self.addLayout(temperature_layout)

        self.wind_speed=QLabel("🌫 15м/c")
        self.wind_speed.setStyleSheet("color: "+extra_color+";"
                                               "font-family: Helvetica;"
                                               "font-size: 19px;"
                                               "font-weight: 200;"
                                               "margin-left:5px;")
        self.wind_speed.setAlignment(Qt.AlignLeft)

        self.relative_humidity = QLabel("💧 100%")
        self.relative_humidity.setStyleSheet("color: "+extra_color+";"
                                      "font-family: Helvetica;"
                                      "font-size: 19px;"
                                      "font-weight: 200;"
                                      "margin-left:5px;")
        self.relative_humidity.setAlignment(Qt.AlignLeft)

        wind_relative_layout=QHBoxLayout()
        wind_relative_layout.addWidget(self.wind_speed)
        wind_relative_layout.addWidget(self.relative_humidity)

        self.addLayout(wind_relative_layout)

        self.weather_description = QLabel("Снежный ливень")
        self.weather_description.setStyleSheet("color: "+extra_color+";"
                                               "font-family: Helvetica;"
                                               "font-size: 23px;"
                                               "font-weight: 200;"
                                               "margin-left:5px;")
        self.weather_description.setAlignment(Qt.AlignLeft)
        self.addWidget(self.weather_description)


    def get_layout(self):
        return self

    def set_info(self,weekdate,month_date,img_path,temperature,feeling_temperature,wind_speed,relative_humidity, weather_description):
        self.weekdate.setText(weekdate)
        self.month_date.setText(month_date)
        pixmap=QPixmap(img_path)
        self.img_weather.setPixmap(pixmap)
        self.temperature.setText(temperature)
        self.feeling_temperature.setText(feeling_temperature)
        self.wind_speed.setText(wind_speed)
        self.relative_humidity.setText(relative_humidity)
        self.weather_description.setText(weather_description)

class Weather_big_cities(QHBoxLayout):
    def __init__(self,background_color,card_background_color,extra_color,main_color,main_color2,refresh_background_color):
        super().__init__()
        self.img_weather = QLabel()
        pixmap = QPixmap("images/forecast/sun_clear/sun.png")
        self.img_weather.setFixedSize(50, 50)
        self.img_weather.setStyleSheet("border:none;"
                                       "margin-left:5px;")
        self.img_weather.setPixmap(pixmap)
        self.img_weather.setScaledContents(True)

        self.addWidget(self.img_weather)
        self.setSpacing(0)

        self.temperature = QLabel("+23°")
        self.temperature.setStyleSheet("color: "+extra_color+";"
                                       "font-family: Helvetica;"
                                       "font-size: 25px;"
                                       "font-weight: 400;"
                                       "margin-left:5px;")
        self.temperature.setFixedSize(75,30)
        self.temperature.setAlignment(Qt.AlignCenter)

        self.addWidget(self.temperature)

        self.name = QLabel("Москва")
        self.name.setStyleSheet("color: "+main_color2+";"
                                       "font-family: Helvetica;"
                                       "font-size: 25px;"
                                       "font-weight: 500;"
                                       "margin-left:5px;"
                                )
        self.name.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.name.setFixedSize(230,30)


        self.addWidget(self.name)
    def get_layout(self):
        return self
    def set_info(self,img_path,temperature,i):
        pixmap = QPixmap(img_path)
        self.img_weather.setPixmap(pixmap)
        self.temperature.setText(temperature)
        self.name.setText(i)

class PushWidget(QVBoxLayout):
    def __init__(self,background_color,card_background_color,extra_color,main_color,main_color2,refresh_background_color):
        super().__init__()
        with open("languages/language.settings",'r') as file:
            self.language_code=file.read()
        with open("languages/"+self.language_code+"/language.json",encoding='utf-8') as file:
            self.language=json.load(file)
        self.top_layout=QHBoxLayout()

        self.name_allert=QLabel(self.language["notification"])
        self.name_allert.setStyleSheet("color:"+main_color+";"
                                "font-size: 24px;"
                                "font-weight:500;"
                                "font-family: Helvetica;"
                                "border: none;")
        self.name_allert.setFixedHeight(30)
        self.name_allert.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.top_layout.addWidget(self.name_allert)

        self.close_btn=QPushButton("✕")
        self.close_btn.setFixedSize(30,30)
        self.close_btn.setStyleSheet("QPushButton{"
                                     "color:"+main_color+";"
                                     "font-size: 26px;"
                                     "font-weight: 200;"
                                     "border:none;"
                                     "}"
                                     "QPushButton::hover{"
                                     "background-color:red;"
                                     "border:none;"
                                     "border-radius:10px;"
                                     "}")
        self.top_layout.addWidget(self.close_btn)

        self.text_msg=QLabel(self.language["loading"])
        self.text_msg.setStyleSheet("color:"+main_color+";"
                                "font-size: 22px;"
                                "font-weight:500;"
                                "font-family: Helvetica;"
                                "border:none;")
        self.text_msg.setAlignment(Qt.AlignCenter)

        self.addLayout(self.top_layout)
        self.addWidget(self.text_msg)

    def setText(self,text):
        self.text_msg.setText(text)

class ColorButton(QPushButton):

    colorChanged = pyqtSignal(object)

    def __init__(self, *args, color=None, **kwargs):
        super().__init__(*args, **kwargs)

        self._color = None
        self._default = color
        self.pressed.connect(self.onColorPicker)

        self.setColor(self._default)
    def setColor(self, color):
        if color != self._color:
            self._color = color
            self.colorChanged.emit(color)

    def color(self):
        return self._color

    def onColorPicker(self):
        dlg = QColorDialog(self)
        if self._color:
            dlg.setCurrentColor(QColor(self._color))

        if dlg.exec_():
            self.setColor(dlg.currentColor().name())

    def mousePressEvent(self, e):
        if e.button() == Qt.RightButton:
            self.setColor(self._default)

        return super().mousePressEvent(e)

# Warning: This project is developed by sdqsz2 and Dio using the free API Open-Meteo, PyQt5.
# Commercial use is prohibited according to the API terms of use.
# Предупреждение: Данный проект разработан sdqsz2 и Dio с использованием бесплатного API Open-Meteo, PyQt5.
# Коммерческое использование запрещено в соответствии с условиями использования API.